for getallen in range(20, 50, 2):
    print(getallen)
    