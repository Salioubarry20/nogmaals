for i in range(30,0,-1):
    print(i)