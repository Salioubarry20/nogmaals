for uur in range(1,24):
    if uur <= 12:
        print(uur, 'AM')
    if uur >= 13:
        print(uur, 'PM')
